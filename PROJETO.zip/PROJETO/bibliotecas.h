#ifndef BIBLIOTECAS_H
#define BIBLIOTECAS_H

#include "aluno.h"
#include "paciente.h"
#include "supervisor.h"
#include "atendimento.h"
#include "agendamento.h"
#include "arquivo_funcoes.h"
#include "define_constants.h"
#include "interface.h"

#endif
